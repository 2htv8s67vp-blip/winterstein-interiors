# Winterstein Interiors – GitHub-Vorschau

Statische Designvorschau mit Unterseiten und lokalen Beispielbildern.

## Vorschau veröffentlichen
1. Neues GitHub-Repository erstellen.
2. Alle Dateien aus diesem Ordner in das Repository hochladen (index.html muss im Root liegen).
3. In Settings → Pages, Deploy from a branch, main und / (root) auswählen.
4. Nach Veröffentlichung die von GitHub angezeigte Pages-URL verwenden.

Wichtig: Dies ist eine Designvorschau, keine geprüfte 1:1-Übernahme der Bestandswebsite. Rechtstexte, Originalbilder und Freigaben vor öffentlicher Nutzung ergänzen.
